import React from 'react'
export default function Contact() {
  return (
    <div className="kicker">
      <h3>Contact</h3>
      <p>
        Add your email, social links, or a contact form here. You can also put legal or privacy links in the footer below.
      </p>
    </div>
  )
}