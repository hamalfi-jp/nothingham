import React from 'react'
export default function Projects() {
  return (
    <div className="kicker">
      <h3>Projects</h3>
      <ul style={{margin:0, paddingLeft:'1.2rem'}}>
        <li>Project A — brief description and link</li>
        <li>Project B — brief description and link</li>
        <li>Project C — brief description and link</li>
      </ul>
    </div>
  )
}