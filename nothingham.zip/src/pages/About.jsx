import React from 'react'
export default function About() {
  return (
    <div className="kicker">
      <h3>About</h3>
      <p>
        This section demonstrates navigation while keeping the animated visual persistent.
        You can replace this copy with your own brand story, product summary, or documentation snippets.
      </p>
    </div>
  )
}